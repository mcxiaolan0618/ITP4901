package com.example.lab3ex4;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

public class MainActivity extends AppCompatActivity {

    RecyclerView rvPlanet;
    MyAdapter myAdapter;
    String[] dataArray;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(SavedInstanceState);
        setContentView(R.layout.activity_main);

        rvPlanet = findViewById(R.id.rvPlanet);
        dataArray = getResources().getStringArray((R.array.planets_array));
        rvPlanet.setLayoutManager(new LinearLayoutManager());
        myAdapter = new MyAdapter(this.dataArray);
        rvPlanet.setAdapter(myAdapter);
    }
}